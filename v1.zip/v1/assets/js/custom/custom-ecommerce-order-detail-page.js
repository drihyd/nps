/*
----------------------------------------------------
    : Custom - eCommerce Order Detsil Page js :
----------------------------------------------------
*/
"use strict";
$(document).ready(function() {
    $('.chat-body').slimscroll({
        height: '440',
        position: 'right',
        size: "7px",
        color: '#CFD8DC'
    });
});